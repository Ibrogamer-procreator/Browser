ONE BROWSER — WEBSITE VERSION

This is a static website. To use it online without installing anything:
1. Upload index.html to a static website host allowed by your school.
2. Open the published URL in Chrome on your Chromebook.

Important:
- A single HTML file cannot replace Chrome itself.
- Some websites block iframe embedding and may appear blank. Use the page's external-open link.
- This does not bypass school-managed restrictions or blocked websites.
